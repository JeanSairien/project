#Challenge_4

Bonjour, voici un exercice vous permettant de vous entrainer sur Bootsrap. Aucun rendu n'est attendu, mais je peux le corriger si vous le souhaitez. Travail à réaliser à deux pour le 14 Juin 2016.

Pour la petite histoire : c'est un thème créé pour les débutants de Bootstrap, et vu que vous êtes des cracks... Bah vous allez coder ce thème au lieu de l'utiliser!

## Les règles tout d'abord :

* Règle n°1 : Utiliser les classes de bootstrap au maximum. Ne trichez pas, je les corrige.

* Règle n°2 : La navbar est fixe et suis la navigation. De plus elle est tranparente quand on arrive sur la page et devient blanche quand on commence à scroller.

* Règle n°3 : N'oubliez pas les hovers sur les call-to-actions, les liens sur les boutons etc... De plus il y a un hover sur les images, comme montré dans l'image hover_exemple.png

* Règle n°4 : il y a une animation sur les icones de la section "at your service"; elles apparaissent en bounceIn très rapide.

* Règle n°5 : Votre site doit ressembler à maquette_responsive.png une fois qu'on réduit la fenêtre.


## Ressources :

Les images doivent être prises directement depuis la maquette_desktop.

La couleur orange est le : #f05f40 .

Les liens pour la police :

- \<link href="https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css"\>

- \<link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic" rel="stylesheet" type="text/css"\>

Les icones sont générées via font-awesome.

Bon courage!
