# CSS Shaky Animation

I've always loved the shaky
animation style of a lot of cartoons; Squigglevision. The epic
<a href="http://youtu.be/MuOvqeABHvQ">Rejected</a> is a good example.
Here I'm using a CSS animation technique <a href="http://lab.tylergaw.com/css-animated-sprites/">i've used before</a>
to interpolate between frames of text that are slightly different
to accomplish that shaky style in the browser. The images are svg
so they should be nice and crisp at any size or ppi.

[http://lab.tylergaw.com/css-shaky-animation](http://lab.tylergaw.com/css-shaky-animation/)